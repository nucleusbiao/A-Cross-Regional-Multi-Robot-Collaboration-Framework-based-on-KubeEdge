# Navigation Messages

This repository contains messages used by the
[navigation stack](https://github.com/ros-planning/navigation).
Prior to ROS Jade, these messages were part of that repository.

This branch (ros1) is intended for use with ROS Kinetic and above.
